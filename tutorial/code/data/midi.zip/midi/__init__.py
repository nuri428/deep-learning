# -*- coding: ISO-8859-1 -*-

#import MidiOutStream
#import MidiInStream
#import MidiInFile
#import MidiToText